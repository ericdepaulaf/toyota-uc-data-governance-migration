# This Repo is dedicated to Toyota Mortor North America

Responsables:
- [Wagner Silveira](wagner.silveira@databricks.com)


Details:
- Extract current governance permissions
- Apply them to the UC objects